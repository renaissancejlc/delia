Sligoil is a trademark of Ariel Martín Pérez and Meaning Machine Games (2022).
